from django import forms
from .models import Insumo, Producto, Pedido, ProductoInsumo


class InsumoForm(forms.ModelForm):
    class Meta:
        model = Insumo
        fields = ['nombre', 'cantidad_total', 'precio_total','stock']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['nombre'].widget.attrs.update({'class': 'form-control'})
        self.fields['cantidad_total'].widget.attrs.update({'class': 'form-control'})
        self.fields['precio_total'].widget.attrs.update({'class': 'form-control'})
        self.fields['stock'].widget.attrs.update({'class': 'form-control'})
        


class PedidoForm(forms.ModelForm):
    class Meta:
        model = Pedido
        fields = ['cliente_nombre', 'cliente_telefono', 'cliente_email', 'cliente_instagram', 'estado', 'productos']
        widgets = {
            'cliente_nombre': forms.TextInput(attrs={'class': 'form-control'}),
            'cliente_telefono': forms.TextInput(attrs={'class': 'form-control'}),
            'cliente_email': forms.EmailInput(attrs={'class': 'form-control'}),
            'cliente_instagram': forms.TextInput(attrs={'class': 'form-control'}),
            'estado': forms.Select(attrs={'class': 'form-control'}),
            'productos': forms.SelectMultiple(attrs={'class': 'form-control'}),
        }

class ProductoForm(forms.ModelForm):
    class Meta:
        model = Producto
        fields = ['nombre', 'margen_ganancia']

   # insumos = forms.ModelMultipleChoiceField(
   #     queryset=Insumo.objects.all(),
   #     widget=forms.CheckboxSelectMultiple,
   #     required=False
   # )

class ProductoInsumoForm(forms.ModelForm):
    class Meta:
        model = ProductoInsumo
        fields = ['insumo', 'cantidad']
