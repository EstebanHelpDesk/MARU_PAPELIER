
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('insumos/', views.listar_insumos, name='listar_insumos'),
    path('insumos/agregar/', views.agregar_insumo, name='agregar_insumo'),
    path('productos/', views.listar_productos, name='listar_productos'),
    path('pedidos/', views.listar_pedidos, name='listar_pedidos'),
    path('productos/agregar/', views.agregar_producto, name='agregar_producto'),
    path('productos/editar/<int:producto_id>/', views.editar_producto, name='editar_producto'),
    path('productos/eliminar/<int:producto_id>/', views.eliminar_producto, name='eliminar_producto'),
    path('insumos/editar/<int:insumo_id>/', views.editar_insumo, name='editar_insumo'),
    path('insumos/eliminar/<int:insumo_id>/', views.eliminar_insumo, name='eliminar_insumo'),
]
