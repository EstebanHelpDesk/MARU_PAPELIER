from django.shortcuts import render, redirect, get_object_or_404
from .models import Insumo, Producto, Pedido
from .forms import InsumoForm, ProductoForm, PedidoForm
from .models import  ProductoInsumo, PedidoProducto
from .forms import ProductoInsumoForm
import json
from django.db.models import F, ExpressionWrapper, FloatField


def home(request):
    # Obtener los últimos 15 pedidos que NO estén en estado ENTREGADO
    ultimos_pedidos = Pedido.objects.exclude(estado='ENTREGADO').order_by('-fecha')[:15]
    
    # Anotar a cada insumo el valor del 10% de la cantidad_total
    insumos_bajos = Insumo.objects.annotate(
        threshold=ExpressionWrapper(F('cantidad_total') * 0.1, output_field=FloatField())
    ).filter(stock__lt=F('threshold'))
    
    return render(request, 'gestion/home.html', {
        'ultimos_pedidos': ultimos_pedidos,
        'insumos_bajos': insumos_bajos,
    })

def listar_insumos(request):
    insumos = Insumo.objects.all()
    return render(request, 'gestion/listar_insumos.html', {'insumos': insumos})

def agregar_insumo(request):
    if request.method == "POST":
        form = InsumoForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('listar_insumos')
    else:
        form = InsumoForm()
    return render(request, 'gestion/agregar_insumo.html', {'form': form})


def listar_pedidos(request):
    pedidos = Pedido.objects.all()
    return render(request, 'gestion/listar_pedidos.html', {'pedidos': pedidos})

def listar_productos(request):
    productos = Producto.objects.prefetch_related('insumos', 'productoinsumo_set').all()
    return render(request, 'gestion/listar_productos.html', {'productos': productos})




def agregar_producto(request):
    if request.method == "POST":
        producto_form = ProductoForm(request.POST)
        if producto_form.is_valid():
            producto = producto_form.save(commit=False)
            producto.save()

            # Obtener insumos y cantidades de request.POST
            insumo_ids = request.POST.getlist('insumo')  # Lista de insumos seleccionados
            cantidades = request.POST.getlist('cantidad')  # Lista de cantidades ingresadas

            for insumo_id, cantidad in zip(insumo_ids, cantidades):
                if cantidad and insumo_id:
                    try:
                        insumo = Insumo.objects.get(id=int(insumo_id))  # Obtener insumo por ID
                        ProductoInsumo.objects.create(producto=producto, insumo=insumo, cantidad=float(cantidad))
                    except Insumo.DoesNotExist:
                        pass  # Si el insumo no existe, no lo agrega

            producto.calcular_precios()  # Recalcula costos y precios de venta
            return redirect('listar_productos')
    else:
        producto_form = ProductoForm()

    insumos = Insumo.objects.all()  # Enviar lista de insumos al template
    return render(request, 'gestion/agregar_producto.html', {
        'producto_form': producto_form,
        'insumos': insumos
    })


def eliminar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    if request.method == "POST":
        producto.delete()
        return redirect('listar_productos')

    return render(request, 'gestion/eliminar_producto.html', {'producto': producto})





def editar_producto(request, producto_id):
    producto = get_object_or_404(Producto, id=producto_id)
    
    if request.method == "POST":
        producto_form = ProductoForm(request.POST, instance=producto)
        
        if producto_form.is_valid():
            producto = producto_form.save(commit=False)
            producto.save()

            # Obtener insumos seleccionados y sus cantidades
            insumo_ids = request.POST.getlist('insumo')
            cantidades = request.POST.getlist('cantidad')

            insumo_cantidades = {int(insumo_id): float(cant) for insumo_id, cant in zip(insumo_ids, cantidades) if cant}

            # Eliminar insumos no seleccionados
            producto.productoinsumo_set.exclude(insumo_id__in=insumo_cantidades.keys()).delete()

            # Agregar o actualizar insumos seleccionados
            for insumo_id, cantidad in insumo_cantidades.items():
                insumo = Insumo.objects.get(id=insumo_id)
                producto_insumo, created = ProductoInsumo.objects.get_or_create(producto=producto, insumo=insumo)
                producto_insumo.cantidad = cantidad
                producto_insumo.save()

            producto.calcular_precios()
            return redirect('listar_productos')

    else:
        producto_form = ProductoForm(instance=producto)
        insumos_existentes = producto.productoinsumo_set.all()

    insumos = Insumo.objects.all()
    # 🔹 Convertimos Decimal a float antes de pasarlo a JSON
    insumos_dict = {pi.insumo.id: float(pi.cantidad) for pi in insumos_existentes}

    return render(request, 'gestion/editar_producto.html', {
        'producto_form': producto_form,
        'producto': producto,
        'insumos': insumos,
        'insumos_json': json.dumps(insumos_dict)  # 🔹 Ahora el JSON es válido
    })


def editar_insumo(request, insumo_id):
    insumo = get_object_or_404(Insumo, id=insumo_id)
    if request.method == "POST":
        form = InsumoForm(request.POST, instance=insumo)
        if form.is_valid():
            form.save()
            return redirect('listar_insumos')
    else:
        form = InsumoForm(instance=insumo)
    return render(request, 'gestion/editar_insumo.html', {'form': form, 'insumo': insumo})

def eliminar_insumo(request, insumo_id):
    insumo = get_object_or_404(Insumo, id=insumo_id)
    if request.method == "POST":
        insumo.delete()
        return redirect('listar_insumos')
    return render(request, 'gestion/eliminar_insumo.html', {'insumo': insumo})


def agregar_pedido(request):
    if request.method == "POST":
        # Recoger datos del cliente
        cliente_nombre = request.POST.get('cliente_nombre')
        cliente_telefono = request.POST.get('cliente_telefono')
        cliente_email = request.POST.get('cliente_email')
        cliente_instagram = request.POST.get('cliente_instagram')
        
        pedido = Pedido.objects.create(
            cliente_nombre=cliente_nombre,
            cliente_telefono=cliente_telefono,
            cliente_email=cliente_email,
            cliente_instagram=cliente_instagram,
            estado='NUEVO'
        )
        
        # Recoger productos y cantidades
        producto_ids = request.POST.getlist('producto')
        cantidades = request.POST.getlist('cantidad')
        for producto_id, cantidad in zip(producto_ids, cantidades):
            if producto_id and cantidad:
                producto = Producto.objects.get(id=producto_id)
                PedidoProducto.objects.create(
                    pedido=pedido,
                    producto=producto,
                    cantidad=int(cantidad),
                    precio_snapshot=producto.precio_venta,  # Snapshot del precio actual
                    costo_snapshot=producto.costo_total       # Snapshot del costo actual
                )
        pedido.calcular_totales()
        return redirect('listar_pedidos')
    else:
        productos = Producto.objects.all()
        return render(request, 'gestion/agregar_pedido.html', {'productos': productos})
